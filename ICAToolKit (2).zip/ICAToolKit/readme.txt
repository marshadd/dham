Step 1:
Copy the ICAToolKit folder in C:\ drive

Step 2: 
Install CardMan3x21_V1_1_2_4_winxp.exe  (Omnikey3121 EID reader)
Install EIDAToolkitService.exe (ICP ToolKit)
Install ICAToolkitService.msi  (ICP Agent)
